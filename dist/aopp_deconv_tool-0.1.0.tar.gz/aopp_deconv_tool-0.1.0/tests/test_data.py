import os

test_dir = os.path.abspath(os.path.dirname(__file__))
example_fits_file = os.path.abspath(os.path.join(test_dir, "../example_data/test_rebin.fits"))
example_fits_psf_file = os.path.abspath(os.path.join(test_dir, "../example_data/fit_example_psf_000.fits"))

