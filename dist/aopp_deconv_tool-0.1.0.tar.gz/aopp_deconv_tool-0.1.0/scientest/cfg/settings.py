"""
Setting for the package
"""
from pathlib import Path

root_test_output_dir = Path.cwd() / "test_output"
root_test_output_dir_remove_old_dirs_mode = 10



