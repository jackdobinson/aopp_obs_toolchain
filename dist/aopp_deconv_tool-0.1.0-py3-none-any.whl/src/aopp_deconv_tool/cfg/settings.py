"""
Setting for the package
"""

