"""
Configuration for the package
"""
