


class TestSkippedException(Exception):
	pass
	